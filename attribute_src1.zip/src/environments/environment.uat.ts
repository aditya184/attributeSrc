export const environment = {
    production: false,
    archiveURL: "/sites/medcomuatArchive"
  };