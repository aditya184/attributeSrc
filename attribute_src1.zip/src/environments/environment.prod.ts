export const environment = {
  production: true,
  archiveURL: "/sites/medcomarchive"
};
